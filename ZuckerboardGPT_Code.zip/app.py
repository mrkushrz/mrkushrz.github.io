import sys
from flask import Flask, request, jsonify, Response
from flask_cors import CORS

# Pfad zum Verzeichnis des Skripts hinzufügen
sys.path.append(r"C:\Users\janni\Desktop\DT-Projekt\backend_zuckerboardgpt_conversation_v3.py")

from backend_zuckerboardgpt_conversation_v3 import generate_response
from backend_zuckerboardgpt_conversation_v3 import generate_conversation

NGROK_URL = 'https://finaigpt-public.eu.ngrok.io'

app = Flask(__name__)
CORS(app)  # Enable CORS for the entire Flask application

@app.route("/")
def index():
    return Response("Flask-Server läuft!", mimetype='text/plain')


@app.route("/generate_response", methods=["POST"])
def handle_generate_response():
    data = request.json
    start_date = data.get('start_date')
    end_date = data.get('end_date')
    commodity = data.get('commodity')
    prompt_type = data.get('prompt_type')

    if not all([start_date, end_date, commodity, prompt_type]):
        missing = [k for k in ['start_date', 'end_date', 'commodity', 'prompt_type'] if not data.get(k)]
        return jsonify({'error': 'Missing required data', 'missing': missing}), 400

    try:
        response_data = generate_response(start_date, end_date, commodity, prompt_type)
        return jsonify({'generatedResponse': response_data})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route("/generate_conversation", methods=["POST"])
def handle_generate_conversation():
    data = request.json
    generatedPrompt = data.get('generatedPrompt')
    generatedText = data.get('generatedText')
    question = data.get('question')

    if not all([generatedPrompt, generatedText, question]):
        missing = [k for k in ['generatedPrompt', 'generatedText', 'question'] if not data.get(k)]
        return jsonify({'error': 'Missing required data', 'missing': missing}), 400

    try:
        response_text = generate_conversation(generatedPrompt, generatedText, question)
        return jsonify({'generatedResponse': response_text})
    except Exception as e:
        return jsonify({'error': str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)